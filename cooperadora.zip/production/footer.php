<footer>
          <div class="pull-right">
            Escuela Tecnica N°1<a href="https://colorlib.com">Gral Savio</a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>
    <div>